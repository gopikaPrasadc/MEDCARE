package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.PageUtilities;

public class Addtocart {
	WebDriver driver;

	public Addtocart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	
	@FindBy(xpath = "//*[@id=\"container\"]/div[1]/section/div/div/div/a[2]")
	public static WebElement addtocartbutton1;
	@FindBy(xpath = "//*[text()='Are you a new customer?']")
	public static WebElement newcustomer;
	@FindBy(xpath = "//*[@type='checkbox']")
	public static WebElement Alexferrocheckbox;
	
	public void addtocartpage() {
		PageUtilities.waitforelementtobeclickable(driver, addtocartbutton1, 4);
		addtocartbutton1.click();
		PageUtilities.waitforelementtobeclickable(driver, newcustomer, 4);
		newcustomer.click();
		PageUtilities.waitforelementtobeclickable(driver, Alexferrocheckbox, 4);
		Alexferrocheckbox.click();
	}
	
	public static String getaddcarttext() {
		String text="Are you a new customer?";
		return text;
	}
}
