package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.PageUtilities;

public class ProductOrderNow {

	WebDriver driver;

	public ProductOrderNow(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//*[@id=\"hyalo-gyn\"]/b")
	public static WebElement OrderNowButtonHyaloProduct;
	@FindBy(xpath = "//*[@id=\"auto\"]/div[4]/div/div[2]/a")
	public static WebElement CheckoutHyaloProduct;
	@FindBy(xpath = "//*[@src='images/pronova/products/20.png']")
	public static WebElement Product1;
	@FindBy(xpath = "//*[text()='Are you a new customer?']")
	public static WebElement newcustomer;
	@FindBy(xpath = "//*[@type='checkbox']")
	public static WebElement Alexferrocheckbox;
	@FindBy(xpath = "//*[@id=\"auto\"]/div[4]/div/div[2]/a")
	public static WebElement checkoutbutton;
	@FindBy(xpath = "//*[@src='/images/bgModalCloseWhiteV2.png']")
	public static WebElement alertbuttonclose;
	@FindBy(xpath = "//*[@id=\"hyalo-gyn\"]/div[2]/p/a/em")
	public static WebElement hyaloproduct;
	@FindBy(xpath = "//*[@class='btnOrderV3 storeDetailOrderingOptioncCl']")
	public static WebElement ordernowbutton1;
	//@FindBy(xpath = "//*[@id=\"auto\"]/div[1]/div/div[3]/div/a[2]")
	//public static WebElement month;

	public void firstproductorderandDismissPopup() {
		PageUtilities.performaction(Product1, driver);
		PageUtilities.isElementLoaded(driver, Product1, 2);
		PageUtilities.waitforelementtobeclickable(driver, OrderNowButtonHyaloProduct, 4);
		OrderNowButtonHyaloProduct.click();
		PageUtilities.waitforelementtobeclickable(driver, alertbuttonclose, 3);
		alertbuttonclose.click();
		
	}
	
	public void orderproduct() {
		PageUtilities.scrollintoview(driver);
		PageUtilities.waitforelementtobeclickable(driver, hyaloproduct, 4);
		hyaloproduct.click();
		PageUtilities.waitforelementtobeclickable(driver, ordernowbutton1, 4);
		ordernowbutton1.click();
		PageUtilities.performaction(CheckoutHyaloProduct, driver);
		PageUtilities.waitforelementtobeclickable(driver, CheckoutHyaloProduct, 4);
		CheckoutHyaloProduct.click();
		PageUtilities.waitforelementtobeclickable(driver, newcustomer, 4);
		newcustomer.click();
		PageUtilities.waitforelementtobeclickable(driver,Alexferrocheckbox, 4);
		Alexferrocheckbox.click();
		
		
	}
	
	
	public void numberincrease() {
		PageUtilities.scrollintoview(driver);
		PageUtilities.waitforelementtobeclickable(driver, hyaloproduct, 4);
		hyaloproduct.click();
		PageUtilities.waitforelementtobeclickable(driver, ordernowbutton1, 4);
		ordernowbutton1.click();
		PageUtilities.alertisPresent(driver, 5);
		Alert a = driver.switchTo().alert();
		//month.click();
		PageUtilities.performaction(checkoutbutton, driver);
		//PageUtilities.isElementVisible(driver, checkoutbutton, 100);
		checkoutbutton.click();
		
		
	}
public static String getmainpagetext() {
	String text="Displaying 1 - 12 out of 54 products";
	return text;
}

public static String getmonthtext() {
	String text="October 28, 2020";
	return text;
}
}
