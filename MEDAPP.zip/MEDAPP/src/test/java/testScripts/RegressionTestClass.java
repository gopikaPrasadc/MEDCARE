package testScripts;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.Addtocart;
import pages.ProductOrderNow;
import utilities.PageUtilities;

public class RegressionTestClass extends TestHelper{
  @Test
  public void checkoutAproductdismiss() {
	  ProductOrderNow productordernow = new ProductOrderNow(driver);
	  productordernow.firstproductorderandDismissPopup();
	  Assert.assertEquals(ProductOrderNow.getmainpagetext(), "Displaying 1 - 12 out of 54 products");
  }
  
  @Test
  public void orderproduct() {
	  ProductOrderNow productordernow = new ProductOrderNow(driver);
	  productordernow.numberincrease();
	  Assert.assertEquals(ProductOrderNow.getmonthtext(), "October 28, 2020");
  }
  
  @Test
  public void addcartview() {
	  Addtocart addcart = new Addtocart(driver);
	  addcart.addtocartpage();
	  Assert.assertEquals(Addtocart.getaddcarttext(), "Are you a new customer?");
  }
  
}
